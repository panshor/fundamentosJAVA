//1. Escriba un programa que pida un número al usuario e indique si es positivo o negativo.
package Condicionalesdobles1;

import java.util.Scanner;

public class CondicionalesDobles1{

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
                System.out.println("Digite 1 para consultar saldo\n" +
"Digite 2 para consignar dinero\n" +
"Digite 3 para retirar dinero\n" +
"Digite 4 para salir\n ");
        int n=leer.nextInt();
        int saldo=0;
        double consignar=0;
        double retiro=0;
        
        
        while(n!=4){
                    System.out.print(""
                + "Digite 1 para consultar saldo\n" +
"Digite 2 para consignar dinero\n" +
"Digite 3 para retirar dinero\n" +
"Digite 4 para salir\n ");
        n=leer.nextInt();
            
        if(n==1){
            
            System.out.println("Su saldo es: "+saldo);
            
        }
        if(n==2){
            
            System.out.println("Cuánto va a consignar: ");
            consignar=leer.nextDouble();
            if(consignar>saldo && consignar<0){
                System.out.println("usted no tiene suficiente dinero para consignar ni el número digitado puede ser negativo \n");
            }
            
        }
        if(n==3){
            System.out.println("Cuánto va a retirar: ");
            retiro=leer.nextDouble();
            if(retiro>saldo && retiro<0){
                System.out.println("Usted no tiene suficiente dinero para retirar ni el número digitado puede ser negativo");
            }
            
            
        }
        
        
        
        
        }
        System.out.println("Gracias por usar el cajero");
        
        
    }
}